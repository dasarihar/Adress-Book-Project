#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<ctype.h>
#include "contact.h"
#include "populate.h"
void initialize(AddressBook *addressBook)
{
    addressBook->contactCount = 0;
    FILE *file = fopen("contacts.txt","r");
    if(file==NULL)
    {
        printf("File is not present");
        return;
    }
    char str[200];
    int i=0;
    while(fgets(str,sizeof(str),file))
    {
        char *name=strtok(str,",");
        char *phone=strtok(NULL,",");
        char *email=strtok(NULL,"\n");
        if(name &&phone && email&& addressBook->contactCount<100)
        {
            strcpy(addressBook->contacts[addressBook->contactCount].name,name);
            strcpy(addressBook->contacts[addressBook->contactCount].phone,phone);
            strcpy(addressBook->contacts[addressBook->contactCount].email,email);  
            addressBook->contactCount++;
        }
        
    } 
    fclose(file);  
}
void saveContactsToFile(AddressBook *addressBook) 
{
    FILE *file = fopen("contacts.txt", "w");  
    if(file == NULL)
    {
        printf("File is not present\n");
        return;
    }
    for(int i = 0; i < addressBook->contactCount; i++)
    {
        fprintf(file, "%s,", addressBook->contacts[i].name);
        fprintf(file, "%s,", addressBook->contacts[i].phone);
        fprintf(file, "%s", addressBook->contacts[i].email);
        putc('\n', file);
    }
    fclose(file);
    printf("Contacts are saved\n"); 
}
void listContacts(AddressBook *addressBook) 
{
    if (addressBook->contactCount == 0) {
        printf("contacts are not available\n");
        return;
    }
    else
    {
        printf("Listing all contacts:\n");
        printf("Name,Phone,Number,Email\n");
        for (int i = 0; i <addressBook->contactCount; i++) 
        {
                printf("%d.",i+1);
                printf("%s ", addressBook->contacts[i].name);
                printf("%s ", addressBook->contacts[i].phone);
                printf("%s\n", addressBook->contacts[i].email);
            }
        
    }
} 

void createContact(AddressBook *addressBook)
{
    char Name[50];
    char Phone[50];
    char Email[50];
    int flag = 0;
    printf("Enter the contact name: ");
    scanf(" %[^\n]", Name);
    for(int i = 0; i < addressBook->contactCount; i++) 
    {
        if(strncmp(Name, addressBook->contacts[i].name, strlen(Name)) == 0)
         {
            printf("This name is already avaiable in the address book\n");
            return; 
    }
    }
    printf("Enter the Phone Number: ");
    scanf(" %[0-9]", Phone);
    if(strlen(Phone) != 10) 
    {
        printf("Phone number should be exactly 10 digits\n");
        return;
    }
    for(int i = 0; i < addressBook->contactCount; i++) {
        if(strncmp(Phone, addressBook->contacts[i].phone, strlen(Phone)) == 0) {
            printf("This Phone Number is already avaliable\n");
            return; 
        }
    }
    printf("Enter the Email: ");
    scanf(" %[^\n]", Email);
    if (strchr(Email, '@') == NULL || strchr(Email, '.') == NULL) 
    {
        printf("Invalid Email\n");
        return;
    }
    
    for(int i = 0; i < addressBook->contactCount; i++) 
    {
        if(strcmp(Email, addressBook->contacts[i].email) == 0) 
        {
            printf("This Email is already avaiable\n");
            return; 
        }
    } 
    int count=addressBook->contactCount;
    addressBook->contactCount++;
    
        strcpy(addressBook->contacts[count].name,Name);
        strcpy(addressBook->contacts[count].phone,Phone);
        strcpy(addressBook->contacts[count].email,Email);
        
        printf("contact created successfully\n");
        
    
}

void searchContact(AddressBook *addressBook) 
{
    int option;
    printf("Select contact by:\n1. Name\n2. Phone\n3. Email\n");
    scanf("%d",&option);
    switch(option)
    {
        case 1:
        {
             char search_name[50];
             int name_Found=0;
             printf("Enter the name to search: ");
             getchar();
             scanf("%[^\n]",search_name);
             for(int i=0;i<addressBook->contactCount;i++)
             {
                if(strstr(addressBook->contacts[i].name,search_name))
                {
                    printf("\ncontact found:\n");
                    printf("Name: %s\n",addressBook->contacts[i].name);
                    printf("Phone: %s\n",addressBook->contacts[i].phone);
                    printf("Email: %s\n",addressBook->contacts[i].email);
                    name_Found=1;
                }
             }
             if(!name_Found)
             {
                printf("contact is not found");
             }
             break;
        }
        case 2:
        {
             char search_Phone[50];
             int phone_Found=0;
             printf("Enter the phone number to search:");
             getchar();
             scanf("%[^\n]",search_Phone);
             for(int i=0;i<addressBook->contactCount;i++)
             {
                if(strstr(addressBook->contacts[i].phone,search_Phone))
                {
                    printf("\ncontact found:\n");
                    printf("Name: %s\n",addressBook->contacts[i].name);
                    printf("Phone: %s\n",addressBook->contacts[i].phone);
                    printf("Email: %s\n",addressBook->contacts[i].email);
                    phone_Found=1;
                }
             }
            if(!phone_Found)
             {
                printf("contact is not found\n");
             }
             break;
        }
        case 3:
        {
             char search_Email[50];
             int email_Found=0;
             printf("Enter the email to search:");
             getchar();
             scanf("%[^\n]",search_Email);
             for(int i=0;i<addressBook->contactCount;i++)
             {
                if(strcmp(search_Email,addressBook->contacts[i].email)==0)
                {
                    printf("\ncontact found:\n");
                    printf("Name: %s\n",addressBook->contacts[i].name);
                    printf("Phone: %s\n",addressBook->contacts[i].phone);
                    printf("Email: %s\n",addressBook->contacts[i].email);
                    email_Found=1;
                }
             }
             if(!email_Found)
             {
               printf("contact is not found\n");
             }
             break;
             
    }
     default:
            printf("Invalid option selected.\n");
            break;
    }
}

void editContact(AddressBook *addressBook)
{
    int option;
    printf("Choose an option\n1. Name\n2. Email\n");
    scanf("%d",&option);
    switch(option)
    {
         case 1:
            char search_Name[50];
            int flag=0;
            printf("Enter the name:");
            getchar();
            scanf("%[^\n]",search_Name);
            printf("Matching contacts:\n");
            int arr[15];
            int j=1;
            int count=0;
            for(int i=0;i<=addressBook->contactCount;i++)
            { 
                
                if(strstr(addressBook->contacts[i].name,search_Name))
                {
                    count++;
                    arr[j]=i;
                    j++;
                    printf("%d.",count);
                    printf("%s\t",addressBook->contacts[i].name);
                    printf("%s\t",addressBook->contacts[i].phone);
                    printf("%s\n",addressBook->contacts[i].email);
                    
                }
            }
            int choice,i=0;
            printf("Enter the choice for editing the contact:");
            scanf("%d",&choice);
                for(i=0;i<=addressBook->contactCount;i++)
                {
                    while(i<=count)
                    {
                       if(i==choice)
                       {
                          int option1,flag1;
                          printf("Enter the option for editing the contact:\n1.name\n2.phone_no\n3.email");
                          scanf("%d",&option1);
                          switch(option1)
                            {
                              case 1:
                              do{
                                    flag1=0;
                                    char new_Name[50];
                                    printf("Enter the name for editing: ");
                                    getchar();
                                    scanf("%[^\n]",new_Name);
                                    for(int j=0;j<=addressBook->contactCount;j++)
                                    {
                                        if(strcmp(addressBook->contacts[j].name,new_Name)==0)
                                        {
                                            flag1=1;
                                            printf("The name already exists\n");
                                            break;
                                        }
                                    }
                                    if(flag1!=1)
                                    { 
                                        strcpy(addressBook->contacts[arr[i]].name,new_Name);
                                        printf("name updated successfully");
                                    }
                              }while(flag1);
                              break;
                               case 2:
                                char new_Phone[50];
                                int flag;
                                do{
                                    flag=1;
                                    printf("Enter the phone number for editing: ");
                                    getchar();
                                    scanf("%[^\n]",new_Phone);
                                    if(strlen(new_Phone)!=10)
                                    {
                                        printf("Error:invalid phone number");
                                        flag=0;
                                    }
                                    else
                                    {
                                         for(int i=0;i<10;i++)
                                         {
                                            if(!isdigit(new_Phone[i]))
                                            {
                                                printf("Error: please enter valid phone number");
                                                flag=0;
                                                break;
                                             }
                                         }
                                    }
                                    for(int j=0;j<=addressBook->contactCount;j++)
                                    {
                                        if(strcmp(addressBook->contacts[j].phone,new_Phone)==0)
                                        {
                                            flag=0;
                                            printf("please try again! the phone number already exists\n");
                                            break;
                                        }
                                    }
                                    if(flag)
                                    {
                                        strcpy(addressBook->contacts[arr[i]].phone,new_Phone);
                                        printf("phone number updated successfully");
                                    }
                                    }while(!flag);
                                    break;
                                    case 3:
                                        int flag3;
                                        do
                                        {
                                            flag3=1;
                                            char new_Email[50];
                                            printf("Enter the email for editing: ");
                                            getchar();
                                            scanf("%[^\n]",new_Email);
                                            for(int j1=0;j1<addressBook->contactCount;j1++)
                                            {
                                                if(strncmp(new_Email,addressBook->contacts[j1].email,strlen(new_Email))==0)
                                                {
                                                    flag3=0;
                                                    printf("The email already exists");
                                                    break;
                                                }
                                            }
                                            if(strchr(new_Email,'@')==NULL || strchr(new_Email,'.')==NULL)
                                            {
                                                printf("\nInvalid email");
                                                flag3=0;
                                            }
                                            if(flag3)
                                            {
                                                strcpy(addressBook->contacts[arr[i]].email,new_Email);
                                                printf("\nNew email updated");
                                            }

                                        }while(!flag3);
                                        break;
                                    default:
                                        printf("Invalid section for editing");
                                        break;
                             }
                        }
                     i++;
                    }
                }
         break;
         case 2:
            char search_Email[50];
            int flag1=0;
            printf("Enter the Email id:");
            getchar();
            scanf("%[^\n]",search_Email);
            printf("All possible contacts are\n");
            int arr1[100];
            int k=1;
            int count1=0;
            for(int i=0;i<=addressBook->contactCount;i++)
            { 
                
                if(strstr(addressBook->contacts[i].email,search_Email))
                {
                    count1++;
                    arr1[k]=i;
                    k++;
                    printf("%d.",count1);
                    printf("%s\t",addressBook->contacts[i].name);
                    printf("%s\t",addressBook->contacts[i].phone);
                    printf("%s",addressBook->contacts[i].email);
                    printf("\n");
                    
                }
            }
            int choice1;
            printf("Enter the choice for editing the contact:");
            scanf("%d",&choice1);
                for(int i=0;i<=addressBook->contactCount;i++)
                {
                    while(i<=count1)
                    {
                       if(i==choice1)
                       {
                          int option2,flag2;
                          printf("Enter the option for editing the contact:\n1.name\n2.phone_no\n3.email");
                          scanf("%d",&option2);
                          switch(option2)
                            {
                              case 1:
                              do{ 
                                flag2=0;
                                char new_Name2[50];
                                printf("Enter the name for editing: ");
                                getchar();
                                scanf("%[^\n]",new_Name2);
                                for(int j=0;j<=addressBook->contactCount;j++)
                                {
                                    if(strcmp(addressBook->contacts[j].name,new_Name2)==0)
                                    {
                                        flag2=1;
                                        printf("please try again! the name already exists\n");
                                        break;
                                    }
                                }
                                if(flag2!=1)
                                {
                                    strcpy(addressBook->contacts[arr1[i]].name,new_Name2);
                                    printf("name updated successfully");
                                }
                              }while(flag2);
                              break;
                               case 2:
                                char new_Phone2[50];
                                int flag;
                                do{
                                    flag=1;
                                    printf("Enter the phone number for editing: ");
                                    getchar();
                                    scanf("%[^\n]",new_Phone2);
                                    if(strlen(new_Phone2)!=10)
                                    {
                                        printf("Error:invalid phone number");
                                        flag=0;
                                    }
                                    else
                                    {
                                         for(int i=0;i<10;i++)
                                         {
                                            if(!isdigit(new_Phone2[i]))
                                            {
                                                printf("Error: please enter valid phone number");
                                                flag=0;
                                                break;
                                             }
                                         }
                                    }
                                    for(int j=0;j<=addressBook->contactCount;j++)
                                    {
                                        if(strcmp(addressBook->contacts[j].phone,new_Phone2)==0)
                                        {
                                            flag=0;
                                            printf("please try again! the phone number already exists\n");
                                            break;
                                        }
                                    }
                                    if(flag)
                                    {
                                        strcpy(addressBook->contacts[arr1[i]].phone,new_Phone2);
                                        printf("phone number updated successfully");
                                    }
                                    }while(!flag);
                                    break;
                                    case 3:
                                    int flag4;
                                    do{
                                        flag4=1;
                                        char new_Email2[50];
                                        printf("Enter the email for editing: ");
                                        getchar();
                                        scanf("%[^\n]",new_Email2);
                                        for(int j1=0;j1<=addressBook->contactCount;j1++)
                                            {
                                                //printf("here->%s\n res->%d\n", addressBook->contacts[j].email,strcasecmp(e_email,addressBook->contacts[j].email));
                                                if(strncmp(new_Email2,addressBook->contacts[j1].email,strlen(new_Email2))==0)
                                                {
                                                    flag4=0;
                                                    printf("The email already exists!please try again");
                                                    break;
                                                }
                                            }
                                        if(strchr(new_Email2,'@')==NULL || strchr(new_Email2,'.')==NULL)
                                        {
                                            printf("\nInvalid email");
                                        }
                                        else
                                        {
                                            strcpy(addressBook->contacts[arr1[i]].email,new_Email2);
                                           
                                        }
                                        if(flag4)
                                        {
                                            printf("\nNew email updated");
                                        }
    
                                    }while(!flag4);
                                    break;
                                    default:
                                        printf("Invalid section for editing");
                                        break;
                             }
                        }
                     i++;
                    }
                }
        }
    }

void deleteContact(AddressBook *addressBook) 
{
    int option;
    int  matchFound = 0;
    printf("\nChoose Option to Delete\n");
    printf("1. Name\n2. Phone Number\n3. Email ID\n");
    printf("Enter your option: ");
    scanf("%d", &option);
    getchar();  
    switch (option) 
    {
        case 1: 
        {
            char searchname[50];
            printf("Enter the Name to Delete the contact: ");
            scanf("%[^\n]", searchname);
            int j=1;
            printf("All possible Contacts:\n");
            for (int i = 0; i < addressBook->contactCount; i++) 
            {
                if (strstr(addressBook->contacts[i].name, searchname)) 
                {
                    printf("%d:%s\t %s\t %s\n", i, addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email);
                     matchFound= 1;
                }
            }
            if (matchFound) 
            {
                int index;
                printf("Enter the index of the contact to delete: ");
                scanf("%d", &index);
                
                if (index >= 0 && index < addressBook->contactCount) 
                {
    
                    for (int i = index; i < addressBook->contactCount - 1; i++) 
                    {
                        addressBook->contacts[i] = addressBook->contacts[i + 1];
                    }
                    addressBook->contactCount--;  
                    printf("Contact deleted successfully.\n");
                } 
                else 
                {
                    printf("Invalid index.\n");
                }
            } 
            else 
            {
                printf("No contacts\n");
            }
            break;
        }
        case 2: 
        {
            char searchPhone[50];
            printf("Enter the Phone Number to Delete: ");
            scanf("%[^\n]", searchPhone);
            
            printf("Contacts:\n");
            for (int i = 0; i < addressBook->contactCount; i++) 
            {
                if (strstr(addressBook->contacts[i].phone, searchPhone)) 
                {
                    printf("%d:%s\t %s\t %s\n", i, addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email);
                     matchFound= 1;
                }
            }
            if (matchFound)
            {
                int index;
                printf("Enter the index of the contact to delete: ");
                scanf("%d", &index);
                
                if (index >= 0 && index < addressBook->contactCount) 
                {
                    for (int i = index; i < addressBook->contactCount - 1; i++) 
                    {
                        addressBook->contacts[i] = addressBook->contacts[i + 1];
                    }
                    addressBook->contactCount--;  
                    printf("Contact deleted successfully.\n");
                } 
                else 
                {
                    printf("Invalid index.\n");
                }
            } 
            else 
            {
                printf("No contacts found with the given phone number.\n");
            }
            break;
        }
        case 3:     
        {
            char searchEmail[50];
            printf("Enter the Email ID to Delete: ");
            scanf(" %[^\n]", searchEmail);  
    
            printf("Matching Contacts:\n");
            int found = 0; 
            for (int i = 0; i < addressBook->contactCount; i++) 
            {
                if (strstr(addressBook->contacts[i].email,  searchEmail)) 
                {
                    printf("%d:%s\t %s\t %s\n", i, addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email);
                    found = 1;
                }
            }
            if (found) 
            {
                int index;
                printf("Enter the index of the contact to delete: ");
                scanf("%d", &index);
            
                if (index >= 0 && index < addressBook->contactCount) 
                {
                    for (int i = index; i < addressBook->contactCount - 1; i++) 
                    {
                        addressBook->contacts[i] = addressBook->contacts[i + 1];
                    }
                    addressBook->contactCount--;  
                    printf("Contact deleted successfully.\n");
                } 
                else 
                {
                    printf("Invalid index.\n");
                }
            } 
            else 
            {
                printf("No contacts found with the given email ID.\n");
            }
        }
        break;
        default :
            printf("Invalid Choice\n");
            break;
        }
    }
   
